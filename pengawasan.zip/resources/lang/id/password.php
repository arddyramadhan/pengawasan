
<?php
return [
    'password' => 'Kata sandi harus minimal enam karakter dan cocok dengan konfirmasi.',
    'reset'    => 'Kata sandi Anda sudah di atur ulang!',
    'sent'     => 'Kami sudah mengirim email yang berisi tautan untuk mengatur ulang kata sandi Anda!',
    'token'    => 'Kata sandi token pengaturan ulang tidak sah.',
    'user'     => 'Kami tidak dapat menemukan pengguna dengan alamat surel tersebut.',
];
